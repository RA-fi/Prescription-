/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_count {
    PreparedStatement pst;
    ResultSet rs;
    cls_DBconection db= new cls_DBconection();
    public void patientCount(){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT count(ID) AS pt FROM tbl_patient");
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
     public void activeCount(){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT count(ID) AS pa FROM tbl_patient WHERE status='1'");
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
     public void waitingCount(){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT count(ID) AS pw FROM tbl_patient WHERE status='0'");
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
      public void medicinenameshow(String key){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT  *FROM tbl_medicine WHERE M_company=? ");
            pst.setString(1,key);
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
      public void companynameshow(){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT  *FROM tbl_medicine ");
            
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
     public void patientidshow(){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT  *FROM tbl_patient ");
            
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
     public void patientothershow(String key){
        try{
         db.conM();
         pst=db.cn.prepareStatement("SELECT *FROM tbl_patient WHERE ID=?");
         pst.setString(1, key);
         rs=pst.executeQuery();
      } 
      catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
          
      }
    }
     public void rxshow(){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT  *FROM tbl_rx ");
            
            rs=pst.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Error" +ex);
        }
    }
}
