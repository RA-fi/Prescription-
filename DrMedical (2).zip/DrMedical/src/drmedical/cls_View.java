/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;
import java.awt.TextField;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.TableModel;



/**
 *
 * @author Green World IT Ltd
 */
public class cls_View {
    
 
    PreparedStatement pst;
    ResultSet rs;
  

    void patient_view(TextField idp,TextField pid, TextField pname, TextField page, TextField paddress, TextField pphone, TextField pstatus, JTable p_table) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         int index=p_table.getSelectedRow();
        TableModel tm=p_table.getModel();
        idp.setText(tm.getValueAt(index,0).toString());
        pid.setText(tm.getValueAt(index,1).toString());
        pname.setText(tm.getValueAt(index,2).toString());
        page.setText(tm.getValueAt(index,3).toString());
        paddress.setText(tm.getValueAt(index,4).toString());
        pphone.setText(tm.getValueAt(index,5).toString());
        pstatus.setText(tm.getValueAt(index,6).toString());
    }
   void medicine_view(TextField idm,TextField mid, TextField mName, TextField cName, TextField sNote,  JTable m_table){
      int index=m_table.getSelectedRow();
        TableModel tm= m_table.getModel();
        idm.setText(tm.getValueAt(index,0).toString());
        mid.setText(tm.getValueAt(index,1).toString());
        mName.setText(tm.getValueAt(index,2).toString());
        cName.setText(tm.getValueAt(index,3).toString());
        sNote.setText(tm.getValueAt(index,4).toString());  
   }
   void rx_view(TextField idrx,TextField rxid, TextField rxname,  TextField rxnote,  JTable rx_table){
        int index=rx_table.getSelectedRow();
        TableModel tm= rx_table.getModel();
        idrx.setText(tm.getValueAt(index,0).toString());
        rxid.setText(tm.getValueAt(index,1).toString());
        rxname.setText(tm.getValueAt(index,2).toString());
        rxnote.setText(tm.getValueAt(index,2).toString());
   }
   void sig_view(TextField idsig,TextField sigid, TextField sig_name,    JTable tbl_sig){
        int index=tbl_sig.getSelectedRow();
        TableModel tm=tbl_sig.getModel();
        idsig.setText(tm.getValueAt(index,0).toString());
        sigid.setText(tm.getValueAt(index,1).toString());
        sig_name.setText(tm.getValueAt(index,2).toString());
       
   }
   void forb_view(TextField idt,TextField tid, TextField tname,    JTable tbl_forbidden){
       int index=tbl_forbidden.getSelectedRow();
        TableModel tm= tbl_forbidden.getModel();
        idt.setText(tm.getValueAt(index,0).toString());
        tid.setText(tm.getValueAt(index,1).toString());
        tname.setText(tm.getValueAt(index,2).toString());
   }
}
