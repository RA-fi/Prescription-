/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.awt.TextField;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_Insert {
    cls_DBconection db= new cls_DBconection();
    PreparedStatement pst=null;
    public void medicine_insert(String mid,String mName,String cName,String sNote){
        
        try
        {
            db.conM();
            pst=db.cn.prepareStatement("INSERT INTO tbl_medicine(m_ID, m_Name, M_company, sNote) VALUES(?,?,?,?)");
            pst.setString(1,mid);
            pst.setString(2,mName);
            pst.setString(3,cName);
            pst.setString(4,sNote);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Insert success");
            
            
            
            
            
        }
        catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Error" +ex);
                }
           
    }
    public void patient_insert(String pid,String pName,String page,String padd,String pphone,String status){
        
        try
        {
             db.conM();
            pst=db.cn.prepareStatement("INSERT INTO tbl_patient(p_ID, pName, page, pass,pphone, status) VALUES(?,?,?,?,?,?)");
            pst.setString(1,pid);
            pst.setString(2,pName);
            pst.setString(3,page);
            pst.setString(4,padd);
            pst.setString(5,pphone);
            pst.setString(6,status);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Insert success");
            
            
            
            
        }
        catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Error" +ex);
                }
           
    }
    public void rx_insert(String rxid,String rxname,String rnote){
        
        try
        {
            db.conM();
            pst=db.cn.prepareStatement("INSERT INTO tbl_rx(rx_ID, rx_Name, rnote) VALUES(?,?,?)");
            pst.setString(1,rxid);
            pst.setString(2,rxname);
            pst.setString(3,rnote);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Insert success");
            
            
            
            
        }
        catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Error" +ex);
                }
           
    }
    
     public void other_insert(String tid,String tname,String tfor){
        
        try
        {
            db.conM();
            pst=db.cn.prepareStatement("INSERT INTO tbl_other(tittle_id, tname, tfor) VALUES(?,?,?)");
            pst.setString(1,tid);
            pst.setString(2,tname);
            pst.setString(3,tfor);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Insert success");
            
            
            
            
        }
        catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Error" +ex);
                }
           
    }
    
     public void sigother_insert(String sigtid,String sigtname,String sigtfor){
        
        try
        {
            db.conM();
            pst=db.cn.prepareStatement("INSERT INTO tbl_other(tittle_id, tname, tfor) VALUES(?,?,?)");
            pst.setString(1,sigtid);
            pst.setString(2,sigtname);
            pst.setString(3,sigtfor);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Insert success");
            
            
            
            
            
        }
        catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Error" +ex);
                }
           
    }
}
