/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_Search {
     PreparedStatement pst;
    ResultSet rs;
    cls_DBconection db= new cls_DBconection();
    public void medicinesearch(String key){
      try{
         db.conM();
         pst=db.cn.prepareStatement("SELECT *FROM tbl_medicine WHERE m_ID=?");
         pst.setString(1, key);
         rs=pst.executeQuery();
      } 
      catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
          
      }
    }
     public void patientsearch(String key){
      try{
         db.conM();
         pst=db.cn.prepareStatement("SELECT *FROM tbl_patient WHERE p_ID=?");
         pst.setString(1, key);
         rs=pst.executeQuery();
      } 
      catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
          
      }
    }
     public void rxsearch(String key){
      try{
         db.conM();
         pst=db.cn.prepareStatement("SELECT *FROM tbl_rx WHERE rx_ID=?");
         pst.setString(1, key);
         rs=pst.executeQuery();
      } 
      catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
          
      }
    }
       public void sigsearch(String key){
      try{
         db.conM();
         pst=db.cn.prepareStatement("SELECT *FROM tbl_other WHERE tittle_id=?");
         pst.setString(1, key);
         rs=pst.executeQuery();
      } 
      catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
          
      }
    }
       public void forbsearch(String key){
      try{
         db.conM();
         pst=db.cn.prepareStatement("SELECT *FROM tbl_other WHERE tittle_id=?");
         pst.setString(1, key);
         rs=pst.executeQuery();
      } 
      catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
          
      }
    }
}
