/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;

import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.SQLException;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_Delete {
    cls_DBconection db= new cls_DBconection();
    PreparedStatement pst;
    public void medicine_delete(String _id){
        try{
    db.conM();
    pst=db.cn.prepareStatement("DELETE FROM tbl_medicine WHERE id=?");
        pst.setString(1,_id);
        pst.executeUpdate();
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
}
    public void patient_delete(String _id){
        try{
    db.conM();
    pst=db.cn.prepareStatement("DELETE FROM tbl_patient WHERE id=?");
        pst.setString(1,_id);
        pst.executeUpdate();
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
}
    public void rx_delete(String _id){
        try{
    db.conM();
    pst=db.cn.prepareStatement("DELETE FROM tbl_rx WHERE id=?");
        pst.setString(1,_id);
        pst.executeUpdate();
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
}
    public void sig_delete(String _id){
        try{
    db.conM();
    pst=db.cn.prepareStatement("DELETE FROM tbl_other WHERE id=?");
        pst.setString(1,_id);
        pst.executeUpdate();
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
}
    public void forb_delete(String _id){
        try{
    db.conM();
    pst=db.cn.prepareStatement("DELETE FROM tbl_other WHERE id=?");
        pst.setString(1,_id);
        pst.executeUpdate();
        }
        catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
}
    
}
