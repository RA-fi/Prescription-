/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_Update {
    cls_DBconection db= new cls_DBconection();
    PreparedStatement pst=null;
    void m_update(String idm,String mid,String mName,String cName,String sNote){
    try
        {
            
            db.conM();
            pst=db.cn.prepareStatement("UPDATE tbl_medicine  WHERE ID='"+idm+"',Set m_ID='"+mid+"',m_Name='"+mName+"',M_company='"+cName+"',sNote='"+sNote+"'");
            
            
           
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Update success");
            
            
            
        }
        catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Error" +ex);
                }
}
}
