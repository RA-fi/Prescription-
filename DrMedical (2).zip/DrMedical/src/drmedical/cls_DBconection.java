/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_DBconection {
    public Connection cn=null;
    public void conM() throws SQLException
            
    {
      cn=DriverManager.getConnection("jdbc:mysql://localhost/dr_management","root","");
      
    }
    
}
