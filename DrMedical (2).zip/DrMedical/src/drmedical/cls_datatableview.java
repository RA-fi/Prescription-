/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drmedical;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Green World IT Ltd
 */
public class cls_datatableview {
    cls_DBconection db=new cls_DBconection();
    
    PreparedStatement pst;
    ResultSet rs;
    
    public void medicineData(JTable m_table){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT *from tbl_medicine");
            rs=pst.executeQuery();
            m_table.setModel(DbUtils.resultSetToTableModel(rs));
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error" +e);
            
        }
    }
     public void patientData(JTable p_table){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT *from tbl_patient");
            rs=pst.executeQuery();
            p_table.setModel(DbUtils.resultSetToTableModel(rs));
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error" +e);
            
        }
    }
     public void sigData(JTable tbl_sig){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT *from tbl_other");
            rs=pst.executeQuery();
            tbl_sig.setModel(DbUtils.resultSetToTableModel(rs));
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error" +e);
            
        }
    }
     public void forbiddenData(JTable tbl_forbidden){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT *from tbl_other");
            rs=pst.executeQuery();
            tbl_forbidden.setModel(DbUtils.resultSetToTableModel(rs));
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error" +e);
            
        }
    }
     public void rxData(JTable rx_table){
        try{
            db.conM();
            pst=db.cn.prepareStatement("SELECT *From tbl_rx");
            rs=pst.executeQuery();
            rx_table.setModel(DbUtils.resultSetToTableModel(rs));
            
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error" +e);
            
        }
    }
}
